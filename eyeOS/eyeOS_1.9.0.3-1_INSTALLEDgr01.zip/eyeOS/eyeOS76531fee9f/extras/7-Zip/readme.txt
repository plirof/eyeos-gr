/*
                                  ____   _____
                                 / __ \ / ____|
                  ___ _   _  ___| |  | | (___
                 / _ \ | | |/ _ \ |  | |\___ \
                |  __/ |_| |  __/ |__| |____) |
                 \___|\__, |\___|\____/|_____/
                       __/ |
                      |___/              1.9

                     Web Operating System
                           eyeOS.org

             eyeOS Engineering Team - www.eyeos.org/team

     eyeOS is released under the GNU Affero General Public License Version 3 (AGPL3)
            provided with this release in license.txt
             or via web at gnu.org/licenses/agpl-3.0.txt

        Copyright 2005-2009 eyeOS Team (team@eyeos.org)
*/

To get eyeSheets working on a Microsoft Windows server please follow these points:

1) Download the Command Line Version of 7-Zip from http://7-zip.org/download.html .
2) Copy the file 7za.exe from the downloaded zip file into this folder.
3) Follow the instructions to get Office support on Windows systems from http://wiki.eyeos.org/Setting_Up_Office_Microsoft .

